"use client";

import { type FormEvent, useEffect, useMemo, useState } from "react";

type WorkoutItem = { id: string; name: string; detail: string; tag: string };
type ViewName = "today" | "calendar" | "plan" | "profile";
type FitnessProfile = {
  age: string;
  gender: string;
  height: string;
  weight: string;
  goal: string;
  experience: string;
  weeklySessions: string;
  duration: string;
  injury: string;
  equipment: string;
  savedAt?: string;
};
type DailyRecord = {
  done?: string[];
  checkedIn?: boolean;
  energy?: number;
  note?: string;
  durationMinutes?: number;
  checkedAt?: string;
};

const workouts: WorkoutItem[] = [
  { id: "warmup", name: "动态热身", detail: "开合跳 · 肩绕环 · 高抬腿", tag: "5 分钟" },
  { id: "squat", name: "深蹲", detail: "4 组 × 12 次", tag: "下肢" },
  { id: "pushup", name: "俯卧撑", detail: "4 组 × 10 次", tag: "胸肩" },
  { id: "plank", name: "平板支撑", detail: "3 组 × 45 秒", tag: "核心" },
  { id: "stretch", name: "拉伸放松", detail: "臀腿 · 胸肩 · 下背", tag: "5 分钟" },
];

const STORAGE_PREFIX = "move-on-";
const PROFILE_STORAGE_KEY = "move-on-profile-v1";
const RETENTION_DAYS = 365;
const WEEK_GOAL = 5;
const weekdayLabels = ["一", "二", "三", "四", "五", "六", "日"];
const weeklyPlan = [
  { day: "周一", name: "全身唤醒", detail: "力量与心肺 · 35 分钟" },
  { day: "周二", name: "下肢力量", detail: "深蹲与臀腿 · 30 分钟" },
  { day: "周三", name: "恢复拉伸", detail: "肩颈与髋部 · 20 分钟" },
  { day: "周五", name: "胸肩核心", detail: "俯卧撑与支撑 · 30 分钟" },
  { day: "周六", name: "低强度有氧", detail: "快走与舒展 · 30 分钟" },
  { day: "周日", name: "自由活动", detail: "快走或轻松骑行 · 30 分钟" },
];

const defaultProfile: FitnessProfile = {
  age: "",
  gender: "prefer-not",
  height: "",
  weight: "",
  goal: "fat-loss",
  experience: "beginner",
  weeklySessions: "3",
  duration: "30",
  injury: "none",
  equipment: "none",
};

function dateKey(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function dateFromKey(key: string) {
  const [year, month, day] = key.split("-").map(Number);
  return new Date(year, month - 1, day, 12);
}

function addDays(date: Date, amount: number) {
  const result = new Date(date);
  result.setDate(result.getDate() + amount);
  return result;
}

function monthStart(date: Date) {
  return new Date(date.getFullYear(), date.getMonth(), 1, 12);
}

function monthId(date: Date) {
  return date.getFullYear() * 12 + date.getMonth();
}

function CalendarIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3v3M17 3v3M4 9h16M5.5 5h13A1.5 1.5 0 0 1 20 6.5v12a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 18.5v-12A1.5 1.5 0 0 1 5.5 5Z" /></svg>;
}

function ChevronIcon({ direction }: { direction: "left" | "right" }) {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d={direction === "left" ? "m15 18-6-6 6-6" : "m9 18 6-6-6-6"} /></svg>;
}

function ClockIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8" /><path d="M12 8v4l3 2" /></svg>;
}

function ShareIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="18" cy="5" r="2.5" /><circle cx="6" cy="12" r="2.5" /><circle cx="18" cy="19" r="2.5" /><path d="m8.3 10.9 7.4-4.6M8.3 13.1l7.4 4.6" /></svg>;
}

export default function Home() {
  const fallbackToday = useMemo(() => new Date(2000, 0, 1, 12), []);
  const [today, setToday] = useState<Date | null>(null);
  const activeToday = today || fallbackToday;
  const todayKey = useMemo(() => dateKey(activeToday), [activeToday]);
  const [done, setDone] = useState<string[]>([]);
  const [checkedIn, setCheckedIn] = useState(false);
  const [energy, setEnergy] = useState(4);
  const [note, setNote] = useState("");
  const [showNote, setShowNote] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [history, setHistory] = useState<Record<string, DailyRecord>>({});
  const [calendarMonth, setCalendarMonth] = useState(() => new Date(2000, 0, 1, 12));
  const [activeView, setActiveView] = useState<ViewName>("today");
  const [profile, setProfile] = useState<FitnessProfile>(defaultProfile);
  const [profileMessage, setProfileMessage] = useState("");
  const [shareMessage, setShareMessage] = useState("");

  useEffect(() => {
    const syncViewFromUrl = () => {
      const requestedView = new URLSearchParams(window.location.search).get("view");
      setActiveView(requestedView === "calendar" || requestedView === "plan" || requestedView === "profile" ? requestedView : "today");
    };
    syncViewFromUrl();
    window.addEventListener("popstate", syncViewFromUrl);
    return () => window.removeEventListener("popstate", syncViewFromUrl);
  }, []);

  useEffect(() => {
    const now = new Date();
    const nowKey = dateKey(now);
    const cutoffKey = dateKey(addDays(now, -(RETENTION_DAYS - 1)));
    const nextHistory: Record<string, DailyRecord> = {};
    let todayRecord: DailyRecord = {};

    for (let index = localStorage.length - 1; index >= 0; index -= 1) {
      const key = localStorage.key(index);
      if (!key?.startsWith(STORAGE_PREFIX)) continue;
      const recordDate = key.slice(STORAGE_PREFIX.length);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(recordDate)) continue;

      if (recordDate < cutoffKey) {
        localStorage.removeItem(key);
        continue;
      }

      try {
        const record = JSON.parse(localStorage.getItem(key) || "{}") as DailyRecord;
        if (recordDate === nowKey) todayRecord = record;
        if (record.checkedIn && recordDate <= nowKey) nextHistory[recordDate] = record;
      } catch {
        localStorage.removeItem(key);
      }
    }

    setDone(Array.isArray(todayRecord.done) ? todayRecord.done : []);
    setCheckedIn(Boolean(todayRecord.checkedIn));
    setEnergy(todayRecord.energy || 4);
    setNote(todayRecord.note || "");
    setHistory(nextHistory);
    try {
      const savedProfile = JSON.parse(localStorage.getItem(PROFILE_STORAGE_KEY) || "null") as FitnessProfile | null;
      if (savedProfile) setProfile({ ...defaultProfile, ...savedProfile });
    } catch {
      localStorage.removeItem(PROFILE_STORAGE_KEY);
    }
    setToday(now);
    setCalendarMonth(monthStart(now));
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (!loaded) return;
    const record: DailyRecord = {
      done,
      checkedIn,
      energy,
      note,
      durationMinutes: checkedIn ? (profile.savedAt ? Number(profile.duration) : 35) : undefined,
      checkedAt: checkedIn ? (history[todayKey]?.checkedAt || new Date().toISOString()) : undefined,
    };
    localStorage.setItem(`${STORAGE_PREFIX}${todayKey}`, JSON.stringify(record));
    setHistory((current) => checkedIn ? { ...current, [todayKey]: record } : current);
    // This effect is the writer for today's record; history is read only to preserve checkedAt.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [done, checkedIn, energy, note, loaded, profile.duration, profile.savedAt, todayKey]);

  const checkinDates = useMemo(() => Object.keys(history).sort(), [history]);
  const checkinDateSet = useMemo(() => new Set(checkinDates), [checkinDates]);
  const firstCheckinKey = checkinDates[0] || null;
  const earliestMonth = useMemo(() => monthStart(firstCheckinKey ? dateFromKey(firstCheckinKey) : activeToday), [activeToday, firstCheckinKey]);
  const currentMonth = useMemo(() => monthStart(activeToday), [activeToday]);

  useEffect(() => {
    if (monthId(calendarMonth) < monthId(earliestMonth)) setCalendarMonth(earliestMonth);
  }, [calendarMonth, earliestMonth]);

  const progress = Math.round((done.length / workouts.length) * 100);
  const allDone = done.length === workouts.length;
  const dateLabel = useMemo(() => new Intl.DateTimeFormat("zh-CN", { month: "long", day: "numeric", weekday: "long" }).format(activeToday), [activeToday]);
  const weekStart = useMemo(() => addDays(activeToday, -((activeToday.getDay() + 6) % 7)), [activeToday]);
  const weekDays = useMemo(() => weekdayLabels.map((day, index) => {
    const date = addDays(weekStart, index);
    const key = dateKey(date);
    return { day, key, done: checkinDateSet.has(key), isToday: key === todayKey };
  }), [checkinDateSet, todayKey, weekStart]);

  const profileReady = Boolean(profile.savedAt && profile.height && profile.weight);
  const weeklyGoal = profileReady ? Number(profile.weeklySessions) : WEEK_GOAL;
  const sessionDuration = profileReady ? Number(profile.duration) : 35;
  const goalLabels: Record<string, string> = {
    "fat-loss": "减脂与体能",
    muscle: "增肌与力量",
    shape: "塑形与稳定",
    fitness: "提升综合体能",
  };
  const workoutTitles: Record<string, string> = {
    "fat-loss": profile.injury === "knee" ? "低冲击燃脂训练" : "全身燃脂循环",
    muscle: "全身力量训练",
    shape: "全身塑形训练",
    fitness: "心肺力量循环",
  };
  const personalizedTitle = profileReady ? workoutTitles[profile.goal] : "全身唤醒训练";
  const injuryGuidance: Record<string, string> = {
    none: "无特殊动作限制",
    knee: "减少跳跃与深蹲幅度，优先低冲击动作",
    back: "减少脊柱负重，优先核心稳定与温和拉伸",
    shoulder: "减少过头推举，优先肩胛稳定动作",
    other: "根据身体反馈降低强度，疼痛时立即停止",
  };
  const personalizedPlan = weeklyPlan.slice(0, weeklyGoal).map((item, index) => {
    if (!profileReady) return item;
    const goalPlans: Record<string, string[]> = {
      "fat-loss": ["低冲击燃脂", "下肢耐力", "恢复拉伸", "全身循环", "轻松有氧", "自由活动"],
      muscle: ["全身力量", "下肢力量", "恢复拉伸", "胸肩核心", "力量进阶", "自由活动"],
      shape: ["全身塑形", "臀腿塑形", "恢复拉伸", "上肢核心", "体态训练", "自由活动"],
      fitness: ["心肺循环", "下肢耐力", "恢复拉伸", "全身体能", "节奏有氧", "自由活动"],
    };
    return { ...item, name: goalPlans[profile.goal]?.[index] || item.name, detail: `${item.detail.split("·")[0].trim()} · ${sessionDuration} 分钟` };
  });

  const thisWeekCount = weekDays.filter((item) => item.done).length;
  const totalMinutes = checkinDates.reduce((sum, key) => sum + (history[key]?.durationMinutes || 35), 0);
  const streak = useMemo(() => {
    let count = 0;
    let cursor = checkinDateSet.has(todayKey) ? activeToday : addDays(activeToday, -1);
    while (checkinDateSet.has(dateKey(cursor))) {
      count += 1;
      cursor = addDays(cursor, -1);
    }
    return count;
  }, [activeToday, checkinDateSet, todayKey]);

  const calendarCells = useMemo(() => {
    const year = calendarMonth.getFullYear();
    const month = calendarMonth.getMonth();
    const firstWeekday = (new Date(year, month, 1).getDay() + 6) % 7;
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells: Array<Date | null> = Array.from({ length: firstWeekday }, () => null);
    for (let day = 1; day <= daysInMonth; day += 1) cells.push(new Date(year, month, day, 12));
    while (cells.length % 7 !== 0) cells.push(null);
    return cells;
  }, [calendarMonth]);

  const calendarTitle = new Intl.DateTimeFormat("zh-CN", { year: "numeric", month: "long" }).format(calendarMonth);
  const canGoPrevious = monthId(calendarMonth) > monthId(earliestMonth);
  const canGoNext = monthId(calendarMonth) < monthId(currentMonth);
  const visibleRangeStart = firstCheckinKey || dateKey(currentMonth);

  function toggleWorkout(id: string) {
    setDone((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  }

  function checkIn() {
    setCheckedIn(true);
    if (!allDone) setDone(workouts.map((item) => item.id));
  }

  function changeCalendarMonth(amount: number) {
    setCalendarMonth((current) => new Date(current.getFullYear(), current.getMonth() + amount, 1, 12));
  }

  function switchView(view: ViewName) {
    const nextUrl = view === "today" ? window.location.pathname : `${window.location.pathname}?view=${view}`;
    window.history.pushState({}, "", nextUrl);
    setActiveView(view);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function saveProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const height = Number(profile.height);
    const weight = Number(profile.weight);
    if (height < 100 || height > 230 || weight < 30 || weight > 250) {
      setProfileMessage("请检查身高和体重：身高应为 100–230 cm，体重应为 30–250 kg。");
      return;
    }
    const savedProfile = { ...profile, savedAt: new Date().toISOString() };
    localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(savedProfile));
    setProfile(savedProfile);
    setProfileMessage("身体档案已保存，训练计划已更新。");
  }

  function clearProfile() {
    if (!window.confirm("确定删除身体档案吗？打卡记录不会受到影响。")) return;
    localStorage.removeItem(PROFILE_STORAGE_KEY);
    setProfile(defaultProfile);
    setProfileMessage("身体档案已删除，计划已恢复为通用版本。");
  }

  async function shareSite() {
    const shareData = {
      title: "MOVE ON 每日健身打卡",
      text: "每天一套清晰的训练，一起坚持打卡。",
      url: window.location.origin,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
        setShareMessage("分享面板已打开");
      } else if (navigator.clipboard) {
        await navigator.clipboard.writeText(shareData.url);
        setShareMessage("链接已复制，朋友打开即可使用");
      } else {
        window.prompt("复制这个网址分享给朋友", shareData.url);
        setShareMessage("朋友打开链接即可使用");
      }
      window.setTimeout(() => setShareMessage(""), 3200);
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      setShareMessage("暂时无法自动分享，请复制浏览器地址");
      window.setTimeout(() => setShareMessage(""), 3200);
    }
  }

  if (!today) {
    return (
      <main className="app-shell boot-shell" aria-busy="true">
        <nav className="topbar" aria-label="主导航">
          <span className="brand"><span className="brand-mark">M</span><span>MOVE ON</span></span>
        </nav>
        <section className="boot-card"><span className="pulse-dot" /><p>正在加载今日训练…</p></section>
      </main>
    );
  }

  return (
    <main className="app-shell">
      <nav className="topbar" aria-label="主导航">
        <button className="brand brand-button" onClick={() => switchView("today")} aria-label="MOVE ON 今日训练"><span className="brand-mark">M</span><span>MOVE ON</span></button>
        <div className="nav-tabs" role="tablist" aria-label="训练视图">
          {(["today", "calendar", "plan", "profile"] as ViewName[]).map((view) => {
            const label = view === "today" ? "今日" : view === "calendar" ? "日历" : view === "plan" ? "计划" : "档案";
            return <button key={view} id={`tab-${view}`} role="tab" aria-selected={activeView === view} aria-controls={`view-${view}`} className={activeView === view ? "active" : ""} onClick={() => switchView(view)}>{label}</button>;
          })}
        </div>
        <div className="topbar-actions">
          <button className="share-button" type="button" onClick={shareSite} aria-label="分享 MOVE ON 给朋友"><ShareIcon /><span>分享</span></button>
          <button className={`avatar ${activeView === "profile" ? "active" : ""}`} onClick={() => switchView("profile")} aria-label="打开身体档案">悦</button>
        </div>
      </nav>

      {shareMessage && <div className="share-toast" role="status" aria-live="polite"><strong>{shareMessage}</strong><span>每个人的数据只保存在自己的设备，互不影响。</span></div>}

      <div className="tab-view" id={`view-${activeView}`} role="tabpanel" aria-labelledby={`tab-${activeView}`}>
      {activeView === "today" && <>
      <section className="hero" id="today">
        <div className="eyebrow"><span className="pulse-dot" /> {dateLabel}</div>
        <h1>今天，也要<br /><em>动起来。</em></h1>
        <p>{profileReady ? `${goalLabels[profile.goal]} · 每周 ${weeklyGoal} 次 · 每次 ${sessionDuration} 分钟` : "不用做到完美，只要比昨天多一点点。"}</p>
        <div className="hero-sticker" aria-hidden="true"><strong>{progress}%</strong><span>今日进度</span></div>
      </section>

      <section className="stats-row" aria-label="健身数据概览">
        <article className="stat-card accent-dark"><span className="stat-icon" aria-hidden="true">↗</span><div><strong>{streak}</strong><small>连续打卡</small></div><span className="unit">天</span></article>
        <article className="stat-card"><span className="stat-icon" aria-hidden="true">●</span><div><strong>{thisWeekCount}</strong><small>本周训练</small></div><span className="unit">/ {weeklyGoal}</span></article>
        <article className="stat-card"><span className="stat-icon" aria-hidden="true">◒</span><div><strong>{totalMinutes}</strong><small>累计训练</small></div><span className="unit">分钟</span></article>
      </section>

      <div className="content-grid">
        <section className="workout-panel" aria-labelledby="workout-title">
          <div className="section-heading">
            <div><span className="kicker">TODAY&apos;S WORKOUT</span><h2 id="workout-title">{personalizedTitle}</h2></div>
            <div className="duration"><ClockIcon /><strong>{sessionDuration}</strong><small>分钟</small></div>
          </div>
          <div className="progress-wrap"><div className="progress-copy"><span>今日完成度</span><strong>{progress}%</strong></div><div className="progress-track"><span style={{ width: `${progress}%` }} /></div></div>
          <div className="workout-list">
            {workouts.map((item, index) => {
              const isDone = done.includes(item.id);
              return <button className={`workout-item ${isDone ? "completed" : ""}`} key={item.id} onClick={() => toggleWorkout(item.id)} aria-pressed={isDone}>
                <span className="exercise-number">{String(index + 1).padStart(2, "0")}</span>
                <span className="exercise-copy"><strong>{item.name}</strong><small>{item.detail}</small></span>
                <span className="exercise-tag">{item.tag}</span><span className="check-circle">{isDone ? "✓" : ""}</span>
              </button>;
            })}
          </div>
          <button className={`checkin-button ${checkedIn ? "done" : ""}`} onClick={checkIn} disabled={checkedIn}>
            <span>{checkedIn ? "今日已打卡" : allDone ? "完成训练并打卡" : "一键完成今日打卡"}</span><b>{checkedIn ? "✓" : "+"}</b>
          </button>
        </section>

        <aside className="side-column">
          <section className="week-card" id="week">
            <div className="week-title"><span>本周节奏</span><strong>{thisWeekCount} / {weeklyGoal}</strong></div>
            <div className="week-days">{weekDays.map((item) => <div className={`day ${item.done ? "done" : ""} ${item.isToday ? "today" : ""}`} key={item.key}><span>{item.day}</span><i>{item.done ? "✓" : item.isToday ? "今" : ""}</i></div>)}</div>
            <p>本周还差 <strong>{Math.max(0, weeklyGoal - thisWeekCount)}</strong> 次达成目标</p>
          </section>
        </aside>
      </div>
      </>}

      {activeView === "calendar" && <>
      <section className="view-hero calendar-view-hero">
        <span className="kicker">YOUR PROGRESS</span>
        <h1>每一次坚持，<br />都清晰可见。</h1>
        <p>从第一次打卡看到今天，最多保留一年的记录。</p>
      </section>

      <section className="stats-row view-stats" aria-label="历史数据概览">
        <article className="stat-card"><span className="stat-icon" aria-hidden="true">↗</span><div><strong>{streak}</strong><small>连续打卡</small></div><span className="unit">天</span></article>
        <article className="stat-card"><span className="stat-icon" aria-hidden="true">●</span><div><strong>{checkinDates.length}</strong><small>有效打卡</small></div><span className="unit">次</span></article>
        <article className="stat-card"><span className="stat-icon" aria-hidden="true">◒</span><div><strong>{totalMinutes}</strong><small>累计训练</small></div><span className="unit">分钟</span></article>
      </section>

      <section className="calendar-panel" id="calendar" aria-labelledby="calendar-title">
        <div className="calendar-header">
          <div className="calendar-heading"><span className="calendar-icon"><CalendarIcon /></span><div><span className="kicker">CHECK-IN CALENDAR</span><h2 id="calendar-title">打卡日历</h2></div></div>
          <div className="calendar-controls" aria-label="切换月份">
            <button onClick={() => changeCalendarMonth(-1)} disabled={!canGoPrevious} aria-label="查看上个月"><ChevronIcon direction="left" /></button>
            <strong aria-live="polite">{calendarTitle}</strong>
            <button onClick={() => changeCalendarMonth(1)} disabled={!canGoNext} aria-label="查看下个月"><ChevronIcon direction="right" /></button>
          </div>
        </div>
        <div className="calendar-weekdays" aria-hidden="true">{weekdayLabels.map((day) => <span key={day}>周{day}</span>)}</div>
        <div className="calendar-grid" role="grid" aria-label={`${calendarTitle}打卡记录`}>
          {calendarCells.map((date, index) => {
            if (!date) return <span className="calendar-blank" key={`blank-${index}`} aria-hidden="true" />;
            const key = dateKey(date);
            const isChecked = checkinDateSet.has(key);
            const isToday = key === todayKey;
            const isMissed = !isChecked && key >= visibleRangeStart && key <= todayKey;
            const status = isChecked ? "已打卡" : isMissed ? "未打卡" : key > todayKey ? "尚未到" : "记录开始前";
            return <div className={`calendar-day ${isChecked ? "checked" : ""} ${isMissed ? "missed" : ""} ${isToday ? "today" : ""}`} key={key} role="gridcell" aria-label={`${date.getMonth() + 1}月${date.getDate()}日，${status}${isToday ? "，今天" : ""}`}>
              <span>{date.getDate()}</span><i aria-hidden="true">{isChecked ? "✓" : isMissed ? "—" : ""}</i>
            </div>;
          })}
        </div>
        <div className="calendar-footer">
          <div className="calendar-legend" aria-label="日历图例"><span><i className="legend-checked" />已打卡</span><span><i className="legend-missed" />未打卡</span><span><i className="legend-today" />今天</span></div>
          <p>{firstCheckinKey ? `记录始于 ${firstCheckinKey.replaceAll("-", "/")}` : "还没有打卡记录，先完成今天的训练吧"} · 仅保存在当前设备 · 自动保留 365 天</p>
        </div>
      </section>
      </>}

      {activeView === "plan" && <>
      <section className="view-hero plan-view-hero">
        <span className="kicker">WEEKLY PLAN</span>
        <h1>按自己的节奏，<br />稳稳练下去。</h1>
        <p>{profileReady ? `${goalLabels[profile.goal]} · ` : ""}本周目标 {weeklyGoal} 次，已完成 {thisWeekCount} 次。</p>
      </section>

      <div className="plan-grid">
        <section className="plan-board" aria-labelledby="plan-title">
          <div className="section-heading">
            <div><span className="kicker">THIS WEEK</span><h2 id="plan-title">本周训练安排</h2></div>
            <div className="plan-count"><strong>{thisWeekCount}</strong><span>/ {weeklyGoal}</span></div>
          </div>
          <div className="plan-list">
            {personalizedPlan.map((item, index) => <article className="plan-item" key={item.day}>
              <span className="plan-number">{String(index + 1).padStart(2, "0")}</span>
              <div><strong>{item.day} · {item.name}</strong><small>{item.detail}</small></div>
              <span className={`plan-status ${index < thisWeekCount ? "complete" : ""}`}>{index < thisWeekCount ? "已完成" : "待训练"}</span>
            </article>)}
          </div>
        </section>

        <aside className="agent-card plan-agent" id="agent">
          <div className="agent-top"><div className="agent-face" aria-hidden="true">M</div><div><span>你的训练搭子</span><h3>Movo Agent</h3></div><span className="online">在线</span></div>
          <div className="speech-bubble"><p>{profileReady ? `${injuryGuidance[profile.injury]}。今天建议完成 ${sessionDuration} 分钟${goalLabels[profile.goal]}训练。` : checkedIn ? "今天的训练已完成。接下来把恢复做好，明天会更轻松。" : progress > 0 ? `已经完成 ${done.length} 项，保持动作质量，剩下的慢慢来。` : "先完善身体档案，我会据此调整训练节奏和动作建议。"}</p></div>
          <div className="energy-block"><label>今天的能量值</label><div className="energy-options" role="group" aria-label="选择今天的能量值">
            {[1, 2, 3, 4, 5].map((value) => <button key={value} onClick={() => setEnergy(value)} className={value === energy ? "selected" : ""} aria-label={`${value} 分`}>{value}</button>)}
          </div></div>
          <button className="secondary-button" onClick={() => setShowNote((value) => !value)} aria-expanded={showNote}><span>{showNote ? "收起训练感受" : "记录训练感受"}</span><span aria-hidden="true">＋</span></button>
          {showNote && <textarea className="note-input" value={note} onChange={(event) => setNote(event.target.value)} placeholder="比如：今天深蹲最后一组有点吃力……" aria-label="训练感受" />}
        </aside>
      </div>
      </>}

      {activeView === "profile" && <>
      <section className="view-hero profile-view-hero">
        <span className="kicker">BODY PROFILE</span>
        <h1>先了解你，<br />再安排训练。</h1>
        <p>身体数据仅保存在当前设备，用于调整训练节奏与动作建议。</p>
      </section>

      <div className="profile-layout">
        <form className="profile-form" onSubmit={saveProfile}>
          <div className="profile-section-heading">
            <div><span className="kicker">BASIC INFO</span><h2>身体与目标</h2></div>
            <span className={`profile-state ${profileReady ? "ready" : ""}`}>{profileReady ? "已完成" : "待完善"}</span>
          </div>

          <div className="form-grid">
            <label><span>身高 <b>必填</b></span><div className="input-with-unit"><input type="number" inputMode="decimal" min="100" max="230" value={profile.height} onChange={(event) => setProfile({ ...profile, height: event.target.value })} required /><i>cm</i></div></label>
            <label><span>体重 <b>必填</b></span><div className="input-with-unit"><input type="number" inputMode="decimal" min="30" max="250" step="0.1" value={profile.weight} onChange={(event) => setProfile({ ...profile, weight: event.target.value })} required /><i>kg</i></div></label>
            <label><span>年龄</span><input type="number" inputMode="numeric" min="12" max="100" value={profile.age} onChange={(event) => setProfile({ ...profile, age: event.target.value })} placeholder="选填" /></label>
            <label><span>性别</span><select value={profile.gender} onChange={(event) => setProfile({ ...profile, gender: event.target.value })}><option value="prefer-not">不透露</option><option value="female">女性</option><option value="male">男性</option></select></label>
            <label><span>健身目标</span><select value={profile.goal} onChange={(event) => setProfile({ ...profile, goal: event.target.value })}><option value="fat-loss">减脂与体能</option><option value="muscle">增肌与力量</option><option value="shape">塑形与稳定</option><option value="fitness">提升综合体能</option></select></label>
            <label><span>训练经验</span><select value={profile.experience} onChange={(event) => setProfile({ ...profile, experience: event.target.value })}><option value="beginner">新手</option><option value="regular">有规律训练</option><option value="advanced">进阶训练者</option></select></label>
            <label><span>每周训练</span><select value={profile.weeklySessions} onChange={(event) => setProfile({ ...profile, weeklySessions: event.target.value })}>{[2, 3, 4, 5, 6].map((value) => <option key={value} value={value}>{value} 次</option>)}</select></label>
            <label><span>单次时长</span><select value={profile.duration} onChange={(event) => setProfile({ ...profile, duration: event.target.value })}>{[20, 30, 40, 50, 60].map((value) => <option key={value} value={value}>{value} 分钟</option>)}</select></label>
            <label><span>身体不适</span><select value={profile.injury} onChange={(event) => setProfile({ ...profile, injury: event.target.value })}><option value="none">无</option><option value="knee">膝部不适</option><option value="back">腰背不适</option><option value="shoulder">肩部不适</option><option value="other">其他不适</option></select></label>
            <label><span>可用器械</span><select value={profile.equipment} onChange={(event) => setProfile({ ...profile, equipment: event.target.value })}><option value="none">无器械</option><option value="dumbbell">哑铃</option><option value="bands">弹力带</option><option value="gym">健身房器械</option></select></label>
          </div>

          <div className="profile-actions">
            <button className="save-profile" type="submit">保存并更新计划</button>
            {profileReady && <button className="clear-profile" type="button" onClick={clearProfile}>删除身体档案</button>}
          </div>
          {profileMessage && <p className="profile-message" role="status">{profileMessage}</p>}
          <p className="medical-note">如有慢性病、孕期、术后恢复或持续疼痛，请先咨询医生或专业教练。</p>
        </form>

        <aside className="profile-preview" aria-live="polite">
          <span className="kicker">YOUR RECOMMENDATION</span>
          <h2>{profileReady ? personalizedTitle : "完成档案后生成建议"}</h2>
          <p>{profileReady ? injuryGuidance[profile.injury] : "填写身高、体重和训练偏好，Movo 会调整计划次数、时长和训练侧重点。"}</p>
          <dl>
            <div><dt>训练方向</dt><dd>{profileReady ? goalLabels[profile.goal] : "待设置"}</dd></div>
            <div><dt>每周频率</dt><dd>{profileReady ? `${weeklyGoal} 次` : "待设置"}</dd></div>
            <div><dt>单次时长</dt><dd>{profileReady ? `${sessionDuration} 分钟` : "待设置"}</dd></div>
            <div><dt>器械条件</dt><dd>{profile.equipment === "none" ? "无器械" : profile.equipment === "dumbbell" ? "哑铃" : profile.equipment === "bands" ? "弹力带" : "健身房器械"}</dd></div>
          </dl>
          <div className="local-data-note"><strong>本机存储</strong><span>这些信息不会上传，清理浏览器数据后会消失。</span></div>
        </aside>
      </div>
      </>}
      </div>
      <footer><span>MOVE ON · 每一次行动，都算数</span><span>为长期主义者设计</span></footer>
    </main>
  );
}
