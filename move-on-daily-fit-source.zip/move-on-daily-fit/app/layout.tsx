import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });

const image = "https://move-on-daily-fit.elizabeth-jacobson42.chatgpt.site/og.png";

export const metadata: Metadata = {
  title: "MOVE ON｜每日健身打卡 Agent",
  description: "每天一套清晰的训练，一次轻松的打卡，一点看得见的进步。",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
  openGraph: {
    title: "MOVE ON｜每日健身打卡 Agent",
    description: "每天动一点，进步看得见。",
    images: [{ url: image, width: 1200, height: 630, alt: "MOVE ON 每日健身打卡 Agent" }],
  },
  twitter: { card: "summary_large_image", images: [image] },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body className={`${geistSans.variable} ${geistMono.variable}`}>{children}</body>
    </html>
  );
}
