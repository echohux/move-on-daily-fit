# MOVE ON · Daily Fitness Check-in

> A lightweight, privacy-first fitness habit product built through vibe coding.

MOVE ON 是一个公开、免登录的每日健身打卡网页。用户可以设置身体档案、查看个性化训练计划、完成每日打卡，并通过日历查看最近一年的记录。

## Product thinking

- **Reduce activation cost:** no registration is required before the first check-in.
- **Make progress visible:** daily completion, streaks and the yearly calendar create an immediate feedback loop.
- **Personalize without surveillance:** profile and training history stay in the browser rather than being uploaded.
- **Design for continuity:** the interface works on both mobile and desktop, with up to 365 days of history.

This repository contains the source code and product documentation. The implementation was created with vibe coding; my focus was the habit loop, information architecture, interaction priorities and privacy trade-offs.

## 直接使用

如果只想使用产品，不需要安装任何软件，直接打开：

[https://move-on-daily-fit.elizabeth-jacobson42.chatgpt.site/](https://move-on-daily-fit.elizabeth-jacobson42.chatgpt.site/)

详细操作方法见 [`MOVE-ON-使用说明.md`](./MOVE-ON-使用说明.md)。

## 主要功能

- 每日训练动作清单与完成进度
- 一键完成当日打卡
- 打卡日历、连续天数和累计训练时长
- 根据身高、体重、目标、训练经验和器械条件生成训练建议
- 最多保留 365 天历史记录
- 桌面端和手机端自适应界面

## 数据如何保存

当前版本使用浏览器本地存储：

- 不需要注册或登录。
- 每个浏览器中的数据相互独立。
- 数据不会自动同步到其他手机或电脑。
- 清除浏览器网站数据后，档案和打卡记录可能会丢失。
- 项目不需要配置数据库或云端账号即可运行。

## 隐私说明

- 公开仓库不包含真实邮箱、账号、API 密钥、数据库凭据或托管项目标识。
- `.env*`、`.openai/`、构建产物和本地缓存均被排除。
- 身体档案和打卡记录只保存在当前浏览器中。
- 清除浏览器数据会同时删除这些记录。

## 本地启动

### 1. 准备环境

需要安装：

- Node.js 22.13.0 或更高版本
- pnpm 11（推荐）

如果电脑尚未安装 pnpm，可在终端运行：

```bash
npm install -g pnpm
```

### 2. 解压项目

解压压缩包后，进入 `MOVE-ON-健身打卡项目` 文件夹。

### 3. 安装依赖

在项目文件夹中打开终端并运行：

```bash
pnpm install
```

### 4. 启动开发版本

```bash
pnpm dev
```

终端显示本地地址后，在浏览器打开：

```text
http://localhost:3000/
```

### 5. 构建正式版本

```bash
pnpm build
```

构建成功后，可以运行：

```bash
pnpm start
```

## 常用命令

| 命令 | 用途 |
| --- | --- |
| `pnpm dev` | 启动本地开发环境 |
| `pnpm build` | 检查并构建正式版本 |
| `pnpm start` | 启动构建后的版本 |
| `pnpm lint` | 检查代码规范 |

## 项目结构

```text
MOVE-ON-健身打卡项目/
├── app/
│   ├── page.tsx          # 页面结构、打卡和个性化逻辑
│   ├── globals.css       # 全站样式和响应式布局
│   └── layout.tsx        # 页面元信息与基础布局
├── public/               # 图标和公开图片
├── tests/                # 页面构建测试
├── worker/               # 托管运行入口
├── MOVE-ON-使用说明.md   # 面向普通用户的操作手册
├── package.json          # 项目依赖和运行命令
└── pnpm-lock.yaml        # 锁定依赖版本
```

## 修改内容

- 修改页面文字或功能：编辑 `app/page.tsx`。
- 修改颜色、间距和响应式样式：编辑 `app/globals.css`。
- 修改网站标题和描述：编辑 `app/layout.tsx`。
- 修改浏览器图标：替换 `public/favicon.svg`。

修改后建议先运行：

```bash
pnpm build
```

确认构建成功后再发布。

## 使用注意事项

本项目提供的是日常健身参考，不替代医疗诊断、康复方案或专业教练指导。如用户处于孕期、术后恢复期，患有慢性疾病，或训练时出现持续疼痛、胸闷、头晕等不适，应立即停止训练，并咨询医生或专业人士。
